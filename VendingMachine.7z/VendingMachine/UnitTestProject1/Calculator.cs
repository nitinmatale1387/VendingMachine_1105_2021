﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VendingMachine;

namespace UnitTestProject1
{
    [TestClass]
    public class Calculator
    {
       
        [TestMethod]
        public void CalculatesChangeAndCoinsRequiredThree()
        {
            VendingMachine.Calculator calculator = new VendingMachine.Calculator();
            double[] returned = calculator.ReturnPaymentAndChange(0.65);

            Assert.AreEqual(1, returned[0]);
            Assert.AreEqual(0, returned[1]);
            Assert.AreEqual(2, returned.Length);
        }

        [TestMethod]
        public void CalculatesChangeAndCoinsRequiredTwo()
        {

            VendingMachine.Calculator calculator = new VendingMachine.Calculator();
            double[] returned = calculator.ReturnPaymentAndChange(0.50);

            Assert.AreEqual(1, returned[0]);
            Assert.AreEqual(0.40, returned[1]);
            Assert.AreEqual(2, returned.Length);
        }

    }
}
