﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VendingMachine;

namespace UnitTestProject1
{
    [TestClass]
    class ProductTest
    {
        [TestMethod]
        public void ProductName()
        {
            Product Cola = new Product("Cola", 1.00);
            Assert.AreEqual("Cola", Cola.Name);
        }

        [TestMethod]
        public void ProductPrice()
        {
            Product Pepsi = new Product("Pepsi", 0.50);
            Assert.AreEqual(0.50, Pepsi.Price);
        }

    }

}
