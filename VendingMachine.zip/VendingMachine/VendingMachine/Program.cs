﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            bool PuchaseVal = true;

            while(PuchaseVal)
            {
               // VendingMachine.SelectProductTemp();




                Coins selectedProduct = VendingMachine.SelectProduct();
                if (selectedProduct != null)
                {
                    bool Flag = VendingMachine.CoinPurchaseDtl(selectedProduct);
                    if (Flag==false)
                    {
                        Console.WriteLine("Want to continue. Enter (Y/N)");
                        string input = Console.ReadLine();
                        PuchaseVal = (input.ToUpper() == "Y");
                    }
                    if (Flag == true)
                        PuchaseVal = false;
                }
            }
                Console.ReadLine();

        }
    }
}
