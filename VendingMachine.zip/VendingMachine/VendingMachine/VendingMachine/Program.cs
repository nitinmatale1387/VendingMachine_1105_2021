﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            var vendingMachine = new VendingMachine();

            vendingMachine.DisplayItems();

            var selectionChar = vendingMachine.RequestSelection();

            Product product = vendingMachine.FindAndReturnProduct(selectionChar);

            Calculator calculator = new Calculator();

            var paymentInfo = calculator.ReturnPaymentAndChange(product.Price);

            vendingMachine.TakePayment(paymentInfo[0], paymentInfo[1], product.Name);
        }
    }
}
