﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    public class Coins
    {
        
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }



        public static List<Coins> GetAllProducts()
        {
            List<Coins> products = new List<Coins>();
            products.Add(new Coins()
            {
                Id = 1,
                Name = "Cola",
                Price = 1.0
            });

            products.Add(new Coins()
            {
                Id = 2,
                Name = "Chips",
                Price = 0.50
            });

            products.Add(new Coins()
            {
                Id = 3,
                Name = "Candy",
                Price = 0.65
            });

            return products;
        }
    }

     
}
