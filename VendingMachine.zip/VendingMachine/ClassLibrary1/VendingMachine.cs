﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VendingMachine
{
    public class VendingMachine
    {

        public static Coins SelectProduct()
        {
            List<Coins> products = Coins.GetAllProducts();
            if (products == null || products.Count == 0)
            {
                Console.WriteLine("Product is not Avliable");
                return null;
            }

            Console.WriteLine("\n Avilable Products: ");
            foreach (Coins product in products)
            {
                Console.WriteLine("{0}\t{1}\t${2:N}", product.Id, product.Name, product.Price);
            }

            Console.WriteLine("\nEnter your Selection: ");

            string selection = Console.ReadLine();
            return SelectProduct(selection);
        }


        public static Coins SelectProduct(string input)
        {
            Coins selectedProduct = VendingMachine.GetProductById(input);
            if (selectedProduct == null)
            {
                Console.WriteLine("Product is not Valid.");
                return null;
            }

            Console.WriteLine("Selected Product: {0}, Price Payable: ${1:N}",
                selectedProduct.Name, selectedProduct.Price);

            return selectedProduct;
        }

        public static Coins GetProductById(string input)
        {
            List<Coins> products = Coins.GetAllProducts();
            if (products == null || products.Count == 0)
                return null;

            int productID = -1;
            if (String.IsNullOrEmpty(input) || !Int32.TryParse(input, out productID))
                productID = -1;

            return products.Find(x => x.Id == productID);
        }



        public static bool CoinPurchaseDtl(Coins objCoin)
        {
            bool isCoinValid = false; string Coins; double CoinValues = 0.0;
            double payablePrice = objCoin.Price, paidAmount = 0.0;
            do
            {
                if (paidAmount != payablePrice)
                {
                    Console.WriteLine("\n Insert Coin:");
                    Console.WriteLine("Details of Coins : 1 = Nickel ($0.05), 2 = Dime ($0.10), 3 =  Quarter ($0.25)");
                    int CoinIput = Convert.ToInt32(Console.ReadLine());
                    isCoinValid = validateCoins(CoinIput, out Coins,out CoinValues);

                    if (!isCoinValid || Coins == null)
                    {
                        Console.WriteLine("Do you want to continue? (Y/N)");
                        string userChoice = Console.ReadLine();
                        if (!String.IsNullOrEmpty(userChoice) && userChoice.ToUpper() == "Y")
                        {
                            continue;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                if (paidAmount + CoinValues > payablePrice)
                    Console.WriteLine("Invalid coin inserted. Pending amount: ${0:N}", payablePrice - paidAmount);
                else
                {
                    paidAmount += CoinValues;
                    paidAmount = Math.Round(paidAmount, 2, MidpointRounding.AwayFromZero);

                    if (paidAmount != payablePrice)
                        Console.WriteLine("Price Payable: ${0:N}\nAmount Paid: ${1:N}\nPending Amount: ${2:N}",
                            payablePrice, paidAmount, payablePrice - paidAmount);
                }


            } while (paidAmount != payablePrice);

            if (paidAmount == payablePrice)
            {
                Console.WriteLine("\nAmount is paid. \nThank you!");
                return true;
            }

            //still here
            return false;

        }

        public static bool validateCoins(int CoinInput, out string strCoin, out double strCoinValue)
        {
            bool isCoinValid; string strCointemp = string.Empty;double strCoinValuetemp = 0.0;
            switch (CoinInput)
            {
                case 1:

                    strCointemp = "Nickel";
                    isCoinValid = true;
                    strCoinValuetemp = 0.05;
                    break;

                case 2:

                    strCointemp = "Dime";
                    strCoinValuetemp = 0.10;
                    isCoinValid = true;
                    break;

                case 3:

                    strCointemp = "Quarter";
                    strCoinValuetemp = 0.25;
                    isCoinValid = true;
                    break;

                default:

                    strCointemp = string.Empty;
                    isCoinValid = false;
                    break;

            }
            strCoin = strCointemp; strCoinValue = strCoinValuetemp;
            return isCoinValid;

        }
    }


}
