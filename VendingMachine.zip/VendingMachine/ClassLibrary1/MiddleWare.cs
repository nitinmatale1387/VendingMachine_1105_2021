﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine;
using static ClassLibrary1.MiddleWare;

namespace ClassLibrary1
{
    public enum CoinType { Nickel = 1, Dime = 2, Quarter = 3, NA = 10000 };

    public class MiddleWare
    {
        public static ICoin GetCoin(CoinType coinType)
        {
            if (coinType == CoinType.Nickel)
                return new Nickel();

            if (coinType == CoinType.Dime)
                return new Dime();

            if (coinType == CoinType.Quarter)
                return new Quarter();

            //still here, invalid coin
            return null;
        }

        public static CoinType GetCoinType(string input)
        {
            CoinType coinType = CoinType.NA;
            if (String.IsNullOrEmpty(input) || !Enum.TryParse<CoinType>(input, out coinType))
                return CoinType.NA;

            //still here
            return coinType;
        }

        public static bool ValidateCoin(string input, out ICoin coin)
        {
            coin = null;

            CoinType coinType = MiddleWare.GetCoinType(input);
            if (coinType == CoinType.NA)
            {
                Console.WriteLine("Invalid coin. Please insert valid coin.");
                return false;
            }

            coin = MiddleWare.GetCoin(coinType);
            if (coin == null)
            {
                Console.WriteLine("Invalid coin. Please insert valid coin.");
                return false;
            }

            Console.WriteLine("\nSelected Coin Type: {0} (${1:N})",
                Enum.GetName(typeof(CoinType), coinType), coin.GetCoinValue());

            return true;
        }
    }

    public class Nickel : ICoin
    {
        public CoinType GetCoinType()
        {
            return CoinType.Nickel;
        }

        public double GetCoinValue()
        {
            return 0.05;
        }
    }

    public class Dime : ICoin
    {
        public CoinType GetCoinType()
        {
            return CoinType.Dime;
        }

        public double GetCoinValue()
        {
            return 0.10;
        }
    }

    public class Quarter : ICoin
    {
        public CoinType GetCoinType()
        {
            return CoinType.Quarter;
        }

        public double GetCoinValue()
        {
            return 0.25;
        }
    }
}

