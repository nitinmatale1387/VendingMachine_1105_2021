﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VendingMachine;

namespace UnitTestProject1
{
    [TestClass]
    public class Calculator
    {

        [TestMethod]
        public void CoinValidationTest()
        {
            double strCoinValue = 1.00;
            string CoinName = "Cola";
            bool actual = VendingMachine.VendingMachine.validateCoins(1, out CoinName, out strCoinValue);
            Assert.AreEqual(strCoinValue, CoinName);

        }
    }
}
